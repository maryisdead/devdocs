# SwagModelPlugin
## About SwagModelPlugin
This skeleton contains a License file, file header and a basic README.

## License

Please see [License File](LICENSE) for more information.