<?php

namespace SwagExtendArticleResource;

use Shopware\Components\Plugin;

class SwagExtendArticleResource extends Plugin
{
}
