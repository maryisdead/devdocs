

Ext.define('Shopware.apps.SwagProduct.view.detail.Window', {
    extend: 'Shopware.window.Detail',
    alias: 'widget.product-detail-window',
    title : '{s name=title}Product details{/s}',
    height: 270,
    width: 680,


//    createTabItems: function() {
//        var me = this,
//            items = me.callParent(arguments);
//
//        items.push(me.createOwnTabItem());
//
//        return items;
//    },
//
//    createOwnTabItem: function() {
//        return Ext.create('Ext.container.Container', {
//            items: [],
//            title: 'My tab item'
//        });
//    },

//    createToolbarItems: function() {
//        var me = this,
//            items = me.callParent(arguments);
//
//        items.push(me.createToolbarButton());
//
//        return items;
//    },
//
//    createToolbarButton: function() {
//        return Ext.create('Ext.button.Button', {
//            text: 'Single Toolbar Button'
//        });
//    }
});
